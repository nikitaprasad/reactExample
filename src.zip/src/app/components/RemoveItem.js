import React from 'react';

class RemoveItem extends React.Component {
    render() {
        return (

            <div>

                <select onChange={this.props.selectChange}>
                    {this.props.data.map((value, ind) => {
                        return <option key={ind} value={value}>{value}</option>
                    })}
                </select>
                <input type="button" onClick={this.props.onClickRemove} value="Remove" />
            </div>
        );
    }
}


export default RemoveItem;