import React from 'react';

 const TextComponent=()=> (<span>Hi Welcome to the app</span> );
 
export default TextComponent;

