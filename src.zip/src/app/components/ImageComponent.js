import React from 'react';

const ImageComponent= () => {
    return <img src= {"./app/pictures/pic.jpg" }/>
};
export default ImageComponent;