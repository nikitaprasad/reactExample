import React from 'react';

 const ListObj={
    home:"Home",
    about:"About",
    contactUs:"Contact Us"
};

export default ListObj;