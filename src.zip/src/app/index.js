import React from 'react';
import RenderDOM from 'react-dom';
import App from './container/App';
import { Provider } from 'react-redux';
import store from "./store";
//import TextComponent from "./components/TextComponent";
//import ImageComponent from "./components/ImageComponent";
//import ListComponent from "./components/ListComponent";
//import ListObj from "./components/ListObj";
//import ButtonToggle from "./components/ButtonToggle";
import AddItem from "./components/AddItem";
import RemoveItem from './components/RemoveItem';





const divStyle = {
    margin: '80px',
    border: '5px solid green'

};

class Shop extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            arr: ['Notebook', 'Pencil'],
            newItem: "",
            removeItem: ""
        };

        this.handleClick = this.handleClick.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleClickRemove = this.handleClickRemove.bind(this);
        this.handleChangeRemove = this.handleChangeRemove.bind(this);
    }

    handleClick() {
        this.setState({ arr: [...this.state.arr, this.state.newItem] });
    }
    handleChange(e) {
        this.setState({ newItem: e.target.value });
    }
    handleChangeRemove(e) {
        this.setState({ removeItem: e.target.value });
    }
    handleClickRemove() {
        this.state.arr.splice(this.state.arr.indexOf(this.state.removeItem), 1);
        this.setState({ arr: this.state.arr });
    }

    render() {

        // const newItem=''

        return (

            <div style={divStyle}>


                <h2>Items available in our store are</h2>

                <ul>
                    {this.state.arr.map((value) => {
                        return <li key={value}>{value}</li>
                    })}
                </ul>
                <AddItem onClick={this.handleClick} onChange={this.handleChange} />
                <RemoveItem data={this.state.arr} selectChange={this.handleChangeRemove} onClickRemove={this.handleClickRemove} />

            </div>
        );
    }
}


RenderDOM.render(<Shop />, document.getElementById('app'));
